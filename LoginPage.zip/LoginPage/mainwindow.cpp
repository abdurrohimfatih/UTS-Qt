#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_loginPushButton_clicked()
{
    if (ui->usernameLineEdit->text() != "" && ui->passwordLineEdit->text() != "") {
        ui->successLabel->setText("Login Success!");
    } else {
        ui->successLabel->setText("Isi username dan password dengan lengkap!");
    }
}

