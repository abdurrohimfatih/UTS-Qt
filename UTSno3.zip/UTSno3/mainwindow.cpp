#include "mainwindow.h"

Dialog::Dialog()
{
    layoutUtama     = new QVBoxLayout;
    layoutA         = new QVBoxLayout;
    layoutB         = new QVBoxLayout;

    labelA          = new QLabel;
    labelB          = new QLabel;

    tombolA         = new QPushButton("Tombol A");
    tombolB         = new QPushButton("Tombol B");

    comboA          = new QComboBox;
    comboB          = new QComboBox;

    labelA->setText("<b>INI LABEL A</b>");
    labelB->setText("<i>INI LABEL B</i>");

    comboA->addItem("KUCING");
    comboA->addItem("AYAM");
    comboA->addItem("SAPI");

    comboB->addItem("JERUK");
    comboB->addItem("STROBERI");
    comboB->addItem("APEL");

    layoutA->addWidget(labelA);
    layoutA->addWidget(tombolA);
    layoutA->addWidget(comboA);
    layoutA->setAlignment(labelA, Qt::AlignHCenter);

    layoutB->addWidget(labelB);
    layoutB->addWidget(tombolB);
    layoutB->addWidget(comboB);
    layoutB->setAlignment(labelB, Qt::AlignHCenter);

    layoutUtama->addLayout(layoutA);
    layoutUtama->addLayout(layoutB);

    setLayout(layoutUtama);
}
