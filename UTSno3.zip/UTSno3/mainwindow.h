#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QMainWindow>
#include <QLayout>
#include <QPushButton>
#include <QLabel>
#include <QComboBox>

class Dialog : public QDialog
{
    Q_OBJECT

public:
    Dialog();

    QVBoxLayout     *layoutUtama;
    QVBoxLayout     *layoutA;
    QVBoxLayout     *layoutB;

    QPushButton     *tombolA;
    QPushButton     *tombolB;

    QComboBox       *comboA;
    QComboBox       *comboB;

    QLabel          *labelA;
    QLabel          *labelB;

private:

};
#endif // MAINWINDOW_H
