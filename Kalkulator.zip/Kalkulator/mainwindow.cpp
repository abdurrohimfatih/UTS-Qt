#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QLayout>
#include <QPushButton>
#include <QIntValidator>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    this->setGeometry(333,333,333,333);
    QHBoxLayout *layout_penambahan = new QHBoxLayout;
    QVBoxLayout *vlayout = new QVBoxLayout;
    QHBoxLayout *layout_pengurangan = new QHBoxLayout;
    QHBoxLayout *layout_perkalian = new QHBoxLayout;
    QHBoxLayout *layout_pembagian = new QHBoxLayout;
    QWidget *widget = new QWidget;

    QPushButton *tombol_tambah = new QPushButton("+");
    QPushButton *tombol_kurang = new QPushButton("-");
    QPushButton *tombol_kali = new QPushButton("x");
    QPushButton *tombol_bagi = new QPushButton("/");

    tombol_tambah->setStyleSheet("QPushButton {background-color: dodgerblue;}");
    tombol_kurang->setStyleSheet("QPushButton {background-color: salmon;}");
    tombol_kali->setStyleSheet("QPushButton {background-color: lightgreen;}");
    tombol_bagi->setStyleSheet("QPushButton {background-color: orange;}");

    input_a = new QLineEdit;
    input_b = new QLineEdit;
    output = new QLineEdit;

    input_a_kurang = new QLineEdit;
    input_b_kurang = new QLineEdit;
    output_kurang = new QLineEdit;

    input_a_kali = new QLineEdit;
    input_b_kali = new QLineEdit;
    output_kali = new QLineEdit;

    input_a_bagi = new QLineEdit;
    input_b_bagi = new QLineEdit;
    output_bagi = new QLineEdit;

    sama_dengan = new QLabel("=");
    sama_dengan_kurang = new QLabel("=");
    sama_dengan_kali = new QLabel("=");
    sama_dengan_bagi = new QLabel("=");

    QIntValidator *valid = new QIntValidator(0,999);

    input_a->setAlignment(Qt::AlignHCenter);
    input_b->setAlignment(Qt::AlignHCenter);
    output->setAlignment(Qt::AlignHCenter);
    input_a->setValidator(valid);
    input_b->setValidator(valid);

    input_a_kurang->setAlignment(Qt::AlignHCenter);
    input_b_kurang->setAlignment(Qt::AlignHCenter);
    output_kurang->setAlignment(Qt::AlignHCenter);
    input_a_kurang->setValidator(valid);
    input_b_kurang->setValidator(valid);

    input_a_kali->setAlignment(Qt::AlignHCenter);
    input_b_kali->setAlignment(Qt::AlignHCenter);
    output_kali->setAlignment(Qt::AlignHCenter);
    input_a_kali->setValidator(valid);
    input_b_kali->setValidator(valid);

    input_a_bagi->setAlignment(Qt::AlignHCenter);
    input_b_bagi->setAlignment(Qt::AlignHCenter);
    output_bagi->setAlignment(Qt::AlignHCenter);
    input_a_bagi->setValidator(valid);
    input_b_bagi->setValidator(valid);

    layout_penambahan->addWidget(input_a);
    layout_penambahan->addWidget(tombol_tambah);
    layout_penambahan->addWidget(input_b);
    layout_penambahan->addWidget(sama_dengan);
    layout_penambahan->addWidget(output);

    layout_pengurangan->addWidget(input_a_kurang);
    layout_pengurangan->addWidget(tombol_kurang);
    layout_pengurangan->addWidget(input_b_kurang);
    layout_pengurangan->addWidget(sama_dengan_kurang);
    layout_pengurangan->addWidget(output_kurang);

    layout_perkalian->addWidget(input_a_kali);
    layout_perkalian->addWidget(tombol_kali);
    layout_perkalian->addWidget(input_b_kali);
    layout_perkalian->addWidget(sama_dengan_kali);
    layout_perkalian->addWidget(output_kali);

    layout_pembagian->addWidget(input_a_bagi);
    layout_pembagian->addWidget(tombol_bagi);
    layout_pembagian->addWidget(input_b_bagi);
    layout_pembagian->addWidget(sama_dengan_bagi);
    layout_pembagian->addWidget(output_bagi);

    vlayout->addLayout(layout_penambahan);
    vlayout->addLayout(layout_pengurangan);
    vlayout->addLayout(layout_perkalian);
    vlayout->addLayout(layout_pembagian);
    widget->setLayout(vlayout);
    setCentralWidget(widget);

    connect(tombol_tambah, SIGNAL(clicked()), this, SLOT(jumlahkan()));
    connect(tombol_kurang, SIGNAL(clicked()), this, SLOT(kurangkan()));
    connect(tombol_kali, SIGNAL(clicked()), this, SLOT(kalikan()));
    connect(tombol_bagi, SIGNAL(clicked()), this, SLOT(bagikan()));
}

void MainWindow::jumlahkan(){
    int casting_a, casting_b;
    nilai_a = input_a->text();
    nilai_b = input_b->text();
    casting_a = nilai_a.toInt();
    casting_b = nilai_b.toInt();

    casting_a = casting_a + casting_b;
    QString recast_a = QString::number(casting_a);
    output->setText(recast_a);
}

void MainWindow::kurangkan(){
    int casting_a, casting_b;
    nilai_a = input_a_kurang->text();
    nilai_b = input_b_kurang->text();
    casting_a = nilai_a.toInt();
    casting_b = nilai_b.toInt();

    casting_a = casting_a - casting_b;
    QString recast_a = QString::number(casting_a);
    output_kurang->setText(recast_a);
}

void MainWindow::kalikan(){
    int casting_a, casting_b;
    nilai_a = input_a_kali->text();
    nilai_b = input_b_kali->text();
    casting_a = nilai_a.toInt();
    casting_b = nilai_b.toInt();

    casting_a = casting_a * casting_b;
    QString recast_a = QString::number(casting_a);
    output_kali->setText(recast_a);
}

void MainWindow::bagikan(){
    int casting_a, casting_b;
    nilai_a = input_a_bagi->text();
    nilai_b = input_b_bagi->text();
    casting_a = nilai_a.toInt();
    casting_b = nilai_b.toInt();

    casting_a = casting_a / casting_b;
    QString recast_a = QString::number(casting_a);
    output_bagi->setText(recast_a);
}

MainWindow::~MainWindow()
{
    delete ui;
}
