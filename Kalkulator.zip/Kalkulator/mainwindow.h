#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QLabel>

QT_BEGIN_NAMESPACE
namespace Ui {
class MainWindow;
}
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public:
    QString nilai_a, nilai_b, nilai_c;
    QString *piala_bergilir;
    QLineEdit *input_a;
    QLineEdit *input_b;
    QLineEdit *output;

    QLineEdit *input_a_kurang;
    QLineEdit *input_b_kurang;
    QLineEdit *output_kurang;

    QLineEdit *input_a_kali;
    QLineEdit *input_b_kali;
    QLineEdit *output_kali;

    QLineEdit *input_a_bagi;
    QLineEdit *input_b_bagi;
    QLineEdit *output_bagi;

    QLabel *sama_dengan;
    QLabel *sama_dengan_kurang;
    QLabel *sama_dengan_kali;
    QLabel *sama_dengan_bagi;

public slots:
    void jumlahkan();
    void kurangkan();
    void kalikan();
    void bagikan();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
